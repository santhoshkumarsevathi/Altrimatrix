package com.altimetrik.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AltimetrikAncestryDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AltimetrikAncestryDemoApplication.class, args);
	}

}
